﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using System.IO;
using System.Reflection;
using DataTable = System.Data.DataTable;

namespace AnalysisApplication
{

    class Program
    {
        #region Declare Variables
        static DataTable dtTableset = new DataTable();
        static SimpleLogger Logger = new SimpleLogger();
        static Dictionary<int, string> loadedAnalysisData = new Dictionary<int, string>();
        static string currentSheet = "Data"; 

        static Excel.Application xlAppReport = null;
        static Excel.Workbook WbookReport = null;
        static Excel.Workbooks WorkbooksReport = null;
        static Excel._Worksheet xlWorksheetReport = null;

        static Excel.Range xlRangeReport = null;

    
        //B1 report
        static string dirPathReport = ""; //ConfigurationManager.AppSettings["B1ReportFilePath"];  //@"\\DDC-SNASPC1-01-VS2-INTERNAL.tmm.na.corp.toyota.com\purdata$\Project Management\00 ES350\MY22_985B\07-Sourcing Phase Activities\T2 Assignment\Sub-tier to DPN Linkage\SAAM Sourcing";//@"C:\Users\459511\Downloads\SubTierDPNLinkage\ExcelWork\Source.xlsx"; //ConfigurationManager.AppSettings["Report"].ToString();


        #endregion
        static async Task Main(string[] args)
        {
            try
            {
                Console.Title = "Analysis Application";
                int count = 0;
                foreach (string file in Directory.EnumerateFiles(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "*.xlsx"))
                {
                    if (!Path.GetFileName(file).ToLower().StartsWith("~"))
                    {
                        count = count + 1;
                        dirPathReport = file;
                    }
                }

                if (count != 1 || string.IsNullOrEmpty(dirPathReport))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please use valid B1 Report file or folder should have only one B1 reprot excel");
                    Logger.Error("Please use valid B1 Report file");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.ReadLine();
                    return;
                }
             

                try
                {

                    Console.WriteLine($"Loading {dirPathReport} file");

                    //Input Report
                    xlAppReport = new Excel.Application();
                    xlAppReport.Visible = false;
                    WorkbooksReport = xlAppReport.Workbooks;
                    WbookReport = WorkbooksReport.Open(dirPathReport, false, false);
                    // get all sheets in workbook
                    Excel.Sheets excelSheets = WbookReport.Worksheets;
                    xlWorksheetReport = (Excel.Worksheet)excelSheets.get_Item(currentSheet);
                    xlRangeReport = xlWorksheetReport.UsedRange;
                    int rowCountReport = xlRangeReport.Rows.Count;
                    int colCountReport = xlRangeReport.Columns.Count;

                    string isHeaderExists = xlRangeReport.Cells[13, 2].Value2;
                    if (string.IsNullOrEmpty(isHeaderExists))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Please use valid Analysis report file");
                        Logger.Error("Please use valid Analysis report file");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.ReadLine();

                        WbookReport.Close(false);
                        xlAppReport.Quit();
                        releaseObject(WorkbooksReport);
                        releaseObject(xlRangeReport);
                        releaseObject(xlWorksheetReport);
                        releaseObject(WorkbooksReport);
                        releaseObject(xlAppReport);

                        Console.WriteLine("Press enter any key to exit " + "\t");
                        return;
                    }

                    Console.WriteLine("Reading file, please wait....");
                    Logger.Info("Reading file, please wait....");
                    System.Data.DataTable dataTable = await Task.Run<DataTable>(() => ConvertToDataTable(14, rowCountReport));
                    Console.WriteLine("Reading completed, please wait....");
                    Logger.Info("Reading completed, please wait....");
                    Console.WriteLine("Gathering records, please wait....");
                    Logger.Info("Gathering records, please wait....");


                    if (dataTable.Rows.Count > 0)
                    {
                        // Create DataView
                        DataView view = new DataView(dataTable);

                        // Sort by State and ZipCode column in descending order
                        view.Sort = "[[REQ] Requisition ID] ASC,[[REQ] Requisition Line Number] DESC";

                        string name = ""; // view[0]["[REQ] Requisition ID]"] as string;
                        foreach (DataRowView item in view)
                        {
                            if(string.IsNullOrEmpty(name))
                            {
                              name= view[0]["[REQ] Requisition ID"] as string;
                                continue;
                            }
                            string Rid = item["[REQ] Requisition ID"] != null ? Convert.ToString(item["[REQ] Requisition ID"]):"";

                            if (name == Rid)
                            {
                                item.Delete();
                            }else
                            {
                                if(!string.IsNullOrEmpty(Rid))
                                {
                                    name = Rid;
                                }
                                
                            }
                        }

                        Random random = new Random();
                        int version = random.Next(1, 100);



                        var xlNewSheet = (Excel.Worksheet)excelSheets.Add(excelSheets[excelSheets.Count], Type.Missing, Type.Missing, Type.Missing);
                        xlNewSheet.Name = "DataAnalysis" + version;

                        int colIndex = 0, rowIndex=0;
                        foreach(DataColumn col in dataTable.Columns)
{
                            colIndex++; xlNewSheet.Cells[1, colIndex] = col.ColumnName;
                        }

                        object[,] arr = new object[view.Count, dataTable.Columns.Count];
                        int topRow = 2;
                        for (int r = 0; r < view.Count; r++)
                        {
                            DataRowView dr = view[r];
                            for (int c = 0; c < dataTable.Columns.Count; c++)
                            {
                                arr[r, c] = dr[c];
                            }
                        }
                        Excel.Range c1 = (Excel.Range)xlNewSheet.Cells[topRow, 1];
                        Excel.Range c2 = (Excel.Range)xlNewSheet.Cells[topRow + view.Count - 1, dataTable.Columns.Count];
                        Excel.Range range = xlNewSheet.get_Range(c1, c2);
                        range.Value = arr;
                        WbookReport.Save();
                        Console.WriteLine("Saving completed");
                        Logger.Info("Saving completed");
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error while reading data " + ex.StackTrace.ToString() + "\t");
                    Console.ForegroundColor = ConsoleColor.White;
                    Logger.Error("Error while reading data  " + ex.Message);
                }
                finally
                {
                    //Release Excel resources  
                    WbookReport.Close(false);
                    xlAppReport.Quit();
                    releaseObject(WorkbooksReport);
                    releaseObject(xlRangeReport);
                    releaseObject(xlWorksheetReport);
                    releaseObject(WorkbooksReport);
                    releaseObject(xlAppReport);

                    Console.WriteLine("Press enter any key to exit " + "\t");
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Logger.Error(ex.Message);
                Console.WriteLine("Press enter any key to exit " + "\t");
            }

            Console.ReadLine();
        }

        static System.Data.DataTable ConvertToDataTable(int startPoint,int endCount)
        {

            System.Data.DataTable dt = null;
            List<int> intColumnsIds = new List<int>() { 3, 4, 5, 6, 11, 12, 16, 19,26, 33 };

            try

            {              

                dt = new System.Data.DataTable();

                System.Data.DataRow row;


                int temp = 2;
                object[,] data = xlRangeReport.Value2;
                while ((data[startPoint-1, temp]) != null)
                {
                    if (intColumnsIds.Contains(temp))
                    {
                        dt.Columns.Add(Convert.ToString((data[startPoint - 1, temp])));
                    }

                    temp++;

                }             

                int columnCount = temp;

                temp = 2;

                for (int rowIndex = startPoint; rowIndex <= endCount; rowIndex++)
                {
                    row = dt.NewRow();
                        int dtColumnCount = 1;
                        for (int i = 1; i < columnCount; i++)

                        {

                            if (intColumnsIds.Contains(i))
                            {
                                row[dtColumnCount - 1] = Convert.ToString((data[rowIndex, i]));
                                dtColumnCount++;
                            }

                        }

                        dt.Rows.Add(row);

                        
                      

                        temp = 2;

                    }
                

               
            }

            catch (Exception ex)

            {

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Unable to read file, error " + ex.Message + "\t");
                Console.ForegroundColor = ConsoleColor.White;
               

            }

            return dt;

        }
      
    

        private static void releaseObject(object obj)
        {
            try
            {
                if (obj != null)
                {
                    Marshal.FinalReleaseComObject(obj);
                    obj = null;
                }
            }
            catch (Exception ex)
            {
                obj = null;
                Console.WriteLine("Unable to release the Object " + ex.ToString());
            }
            //finally
            //{
            //    GC.Collect();
            //}
        }
    }

    public class SimpleLogger
    {
        private const string FILE_EXT = ".log";
        private readonly string datetimeFormat;
        private readonly string logFilename;

        /// <summary>
        /// Initiate an instance of SimpleLogger class constructor.
        /// If log file does not exist, it will be created automatically.
        /// </summary>
        public SimpleLogger()
        {
            datetimeFormat = "yyyy-MM-dd HH:mm:ss.fff";
            logFilename = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + "_Log" + FILE_EXT;

            // Log file header line
            string logHeader = logFilename + " is created.";
            if (!System.IO.File.Exists(logFilename))
            {
                WriteLine(System.DateTime.Now.ToString(datetimeFormat) + " " + logHeader, false);
            }
        }

        /// <summary>
        /// Log a DEBUG message
        /// </summary>
        /// <param name="text">Message</param>
        public void Debug(string text)
        {
            WriteFormattedLog(LogLevel.DEBUG, text);
        }

        /// <summary>
        /// Log an ERROR message
        /// </summary>
        /// <param name="text">Message</param>
        public void Error(string text)
        {
            WriteFormattedLog(LogLevel.ERROR, text);
        }

        /// <summary>
        /// Log a FATAL ERROR message
        /// </summary>
        /// <param name="text">Message</param>
        public void Fatal(string text)
        {
            WriteFormattedLog(LogLevel.FATAL, text);
        }

        /// <summary>
        /// Log an INFO message
        /// </summary>
        /// <param name="text">Message</param>
        public void Info(string text)
        {
            WriteFormattedLog(LogLevel.INFO, text);
        }

        /// <summary>
        /// Log a TRACE message
        /// </summary>
        /// <param name="text">Message</param>
        public void Trace(string text)
        {
            WriteFormattedLog(LogLevel.TRACE, text);
        }

        /// <summary>
        /// Log a WARNING message
        /// </summary>
        /// <param name="text">Message</param>
        public void Warning(string text)
        {
            WriteFormattedLog(LogLevel.WARNING, text);
        }

        private void WriteLine(string text, bool append = true)
        {
            try
            {
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(logFilename, append, System.Text.Encoding.UTF8))
                {
                    if (!string.IsNullOrEmpty(text))
                    {
                        writer.WriteLine(text);
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        private void WriteFormattedLog(LogLevel level, string text)
        {
            string pretext;
            switch (level)
            {
                case LogLevel.TRACE:
                    pretext = System.DateTime.Now.ToString(datetimeFormat) + " [TRACE]   ";
                    break;
                case LogLevel.INFO:
                    pretext = System.DateTime.Now.ToString(datetimeFormat) + " [INFO]    ";
                    break;
                case LogLevel.DEBUG:
                    pretext = System.DateTime.Now.ToString(datetimeFormat) + " [DEBUG]   ";
                    break;
                case LogLevel.WARNING:
                    pretext = System.DateTime.Now.ToString(datetimeFormat) + " [WARNING] ";
                    break;
                case LogLevel.ERROR:
                    pretext = System.DateTime.Now.ToString(datetimeFormat) + " [ERROR]   ";
                    break;
                case LogLevel.FATAL:
                    pretext = System.DateTime.Now.ToString(datetimeFormat) + " [FATAL]   ";
                    break;
                default:
                    pretext = "";
                    break;
            }

            WriteLine(pretext + text);
        }

        [System.Flags]
        private enum LogLevel
        {
            TRACE,
            INFO,
            DEBUG,
            WARNING,
            ERROR,
            FATAL
        }
    }
}
